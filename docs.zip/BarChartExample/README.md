### MyCustomBarChart-Example实现功能 

#### 实现功能1

  ![实现功能](../assets/img/bar1.png ':size=100%')



[视频](../assets/img/1.mp4 ':include :type=video')


[docsify](https://docsify.js.org/#/zh-cn/helpers ':include :type=iframe width=100% height=400px')
