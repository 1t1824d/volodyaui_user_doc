### MyCustomPumpChartLine-Example实现功能 

?> _TODO_ 测试页面地址：http://112.64.170.158:8111/#/

[测试页面地址](http://112.64.170.158:8111/#/ ':crossorgin')

#### 实现功能1

  ![实现功能1](../assets/img/2023-07-22-15-07-08.png ':size=100%')

#### 实现功能2

  ![实现功能2](../assets/img/2023-07-22-15-09-03.png ':size=100%')

#### 实现功能3

   ![实现功能3](../assets/img/c1.png ':size=100%')

#### 实现功能4

   ![实现功能3](../assets/img/p1.png ':size=100%')

#### 实现功能5

   ![实现功能3](../assets/img/p2.png ':size=100%')

#### 实现功能6

   ![实现功能3](../assets/img/p3.png ':size=100%')

#### 实现功能7

   ![实现功能3](../assets/img/p4.png ':size=100%')

#### 实现功能8

   ![实现功能3](../assets/img/p5.png ':size=100%')

#### 实现功能9

   ![实现功能3](../assets/img/p6.png ':size=100%')

#### 实现功能10

   ![实现功能3](../assets/img/p7.png ':size=100%')

#### 实现功能11

   ![实现功能3](../assets/img/p8.png ':size=100%')

#### 实现功能12

   ![实现功能3](../assets/img/p9.png ':size=100%')

#### 实现功能13

   ![实现功能3](../assets/img/p10.png ':size=100%')

